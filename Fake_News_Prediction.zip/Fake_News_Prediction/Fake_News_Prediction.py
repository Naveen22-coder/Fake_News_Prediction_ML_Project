import joblib
import streamlit as st  # Added import for streamlit

# Load the trained model
pipeline = joblib.load(r"D:\Fake_News_Prediction\fake_news_detector.pkl")

# Streamlit UI
st.title("📰 Fake News Detection")
st.write("Enter a news article below and check if it's Real or Fake.")

# Text input
news_text = st.text_area("Enter news text here:")

# Predict button
if st.button("Predict"):
    if news_text.strip() == "":
        st.warning("Please enter some news text!")
    else:
        prediction = pipeline.predict([news_text])[0]
        if prediction == 1:
            st.success("✅ This news is Real")
        else:
            st.error("❌ This news is Fake")